# Cliff-diver badge prototype

This project includes the saved level, all required art and materials, and the gameplay scripts. No scene-generation step is required. The scene builder and automatic first-open generator have been removed.

## Open and play

1. Extract the entire ZIP.
2. In Unity Hub, select Projects > Add project from disk (or Open).
3. Select the extracted **CliffDiver-ReadyToShare** folder containing Assets, Packages, and ProjectSettings.
4. Open with **Unity 6000.6.4f1** and let asset import finish.
5. In the Project window, open **Assets/Scenes/CliffDivePrototype.unity**.
6. Press Play and click the Game view.

The saved level is already first and enabled in the shared build-scene list. The project uses the Built-in render pipeline from the working project that was uploaded.

## Controls and objective

- WASD / arrow keys: walk to the yellow launch pad.
- Space: dive from the launch pad.
- A / D: steer sideways while falling.
- W / S: adjust forward speed while falling.
- R: restart an attempt.

Collect all four gold rings before entering the lake to earn the Cliff-diver's Badge. Missing a ring or the lake resets the attempt and restores all rings.

## Share with the group

Upload this ZIP as a downloadable project, or commit its extracted project files to the intended Git branch. Keep **Assets**, **Packages**, **ProjectSettings**, and all source/scene **.meta** files together. A Unity .gitignore is included to exclude Library, Temp, Logs, Obj, builds, and other local caches.

The files under **Assets/CliffDiversBadge/Generated** are saved mesh and material dependencies. They must stay in the project even though the generator scripts have been removed.

This is a standalone copy of the working saved prototype. When adding it to a repository that already has a different Unity project, keep it in its own prototype folder or integrate the Assets separately; do not overwrite your group's Packages or ProjectSettings unintentionally.

## Credits

- Low-Poly Simple Nature Pack by JustCreate: https://assetstore.unity.com/packages/3d/environments/landscapes/low-poly-simple-nature-pack-162153
- Low Poly: Woods Lifestyle by Rad-Coders: https://assetstore.unity.com/packages/3d/environments/low-poly-woods-lifestyle-65306

## Packaging verification

The saved scene, its generated meshes/materials, source art, runtime scripts, and Unity project settings are preserved byte-for-byte from the uploaded project. Generator scripts and the first-open marker were removed. Asset references and ZIP integrity were checked. The repackaged project has not been reopened in Unity in the packaging environment.
